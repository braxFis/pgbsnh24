﻿namespace Slumpa;
using System.IO;
using System.Text.RegularExpressions;
class Program
{
    static void Main(string[] args)
    {
        System.Console.WriteLine("Skapa en grupp slumpare...GL");
        string readFile = File.ReadAllText("Grupper.txt");
        string writeFile = "";
        MatchCollection matches;
        //System.Console.WriteLine(readFile);
        string rx1 = @"[Grupp]\s\d{1}";
        string rx2 = @"\d{1}\.\s\w{3,15}\s\w{3,20}|\s\w{3,15}\s\w{3,20}\s\w{3,20}|\s\w{3,15}\s\w{3,20}\s\w{3,20\s\w{3,20}";
        Dictionary<string, int> group = new Dictionary<string, int>();
        Random random = new Random();
        matches = Regex.Matches(readFile, rx2);
        //Regex regex = new Regex(rx2);
        //matches = regex.Matches(readFile);
        //System.Console.WriteLine(matches);
        System.Console.WriteLine($"Found a total of {matches.Count} students");
        foreach(Match match in Regex.Matches(readFile, rx2)){
            System.Console.WriteLine($"Found match at Index {match.Index}, the Value is: {match.Value}");
            // if(match.Value.Contains("Nigel")){
                System.Console.WriteLine($"{match.Value}");
                System.Console.WriteLine("Found another member.");
                System.Console.WriteLine($"Which group should YOU be placed in?");
                group.Add(match.Value, random.Next(1,4));
                // if(){
                // }
            // } endif
        } //endforeach
        foreach(KeyValuePair<string, int> kvp in group){
            System.Console.WriteLine($"That is it, {kvp.Key} you're in Group {kvp.Value}");
            // writeFile = File.WriteAllText("NewGroups.txt", "");
            System.Console.WriteLine("The content has been written to the file...");
            System.Console.WriteLine(writeFile);
        } //endforeach

        //Troubleshoot
    }
}