using System.IO;
public class Rx{
    //Steg 1 - Oppna filen "Grupper.pdf"
        // string readFile = File.ReadAllText("Grupper.txt");
    //Steg 2 - Search igenom den efter Grupper-Namn
        // string rx = @"\[Grupp]\";
        // Regex regex = new Regex(rx);

        // System.Console.WriteLine(regex);
    //Steg 3 - Minska 8 grupper till 4 grupper
    //Steg 4 - Slumpa medlemmar utifran en RegEx algoritm
}